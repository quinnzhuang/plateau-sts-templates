/*$(document).ready(function() {
	$("#panel").slideToggle("slow");
	$(this).toggleClass("active"); return false;
});*/
/**
 * add your script doc here
 * @param {String} test
 */
function demo(test) {
  $("#test").text('some text');
}